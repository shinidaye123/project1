<template>
    <div>
        banner
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>

</style>